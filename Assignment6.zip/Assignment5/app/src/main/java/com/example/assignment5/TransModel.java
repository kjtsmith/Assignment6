package com.example.assignment5;

public class TransModel {
    public String mDate, mItem;
    public double mPrice;
}
